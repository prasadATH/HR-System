@extends('layouts.app')

@section('title', 'Home')

@section('content')
<h1 class="text-3xl font-bold">Welcome to the Home Page</h1>
@endsection
