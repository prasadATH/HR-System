

<?php $__env->startSection('title', 'Expenses Details'); ?>

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<h1 class="text-3xl font-bold mb-6">Expenses Details</h1>

<div class="bg-white p-6 rounded shadow-md">
    <h2 class="text-2xl font-bold mb-4">Expenses for <?php echo e($expense->submitted_date); ?></h2>
    <p><strong>Description:</strong> <?php echo e($expense -> description); ?> </p>
    <p><strong>Amount:</strong> <?php echo e(number_format($expense->amount, 2)); ?></p>
    <p><strong>Status:</strong> <?php echo e($expense->status); ?></p>
    <button 
        onclick="window.history.back()" 
        class="bg-blue-500 text-white px-4 py-2 rounded mt-4 hover:bg-blue-600"
    >
        Back to Expenses List
    </button>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Thilina\Documents\Jaan\JaanHR\resources\views/management/expenses/expenses-details.blade.php ENDPATH**/ ?>