

<?php $__env->startSection('title', 'Edit Payroll'); ?>

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<h1 class="text-3xl font-bold mb-6">Edit Payroll</h1>

<div class="bg-white p-6 rounded shadow-md">
    <form action="<?php echo e(route('payroll.update', $payroll->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-4">
            <label class="block text-gray-700 font-bold mb-2">Basic Salary</label>
            <input type="text" name="basic_salary" value="<?php echo e($payroll->basic_salary); ?>" class="w-full p-2 border rounded">
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 font-bold mb-2">Allowances</label>
            <input type="text" name="allowances" value="<?php echo e($payroll->allowances); ?>" class="w-full p-2 border rounded">
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 font-bold mb-2">Deductions</label>
            <input type="text" name="deductions" value="<?php echo e($payroll->deductions); ?>" class="w-full p-2 border rounded">
        </div>

        <div class="mb-4">
            <label class="block text-gray-700 font-bold mb-2">Net Salary</label>
            <input type="text" name="net_salary" value="<?php echo e($payroll->net_salary); ?>" class="w-full p-2 border rounded">
        </div>

        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Update Payroll</button>
        <a href="<?php echo e(route('dashboard.payroll')); ?>" class="bg-gray-500 text-white px-4 py-2 rounded ml-4">Cancel</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Thilina\Documents\Jaan\JaanHR\resources\views/management/payroll/payroll-edit.blade.php ENDPATH**/ ?>