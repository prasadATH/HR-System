

<?php $__env->startSection('title', 'Leave Details'); ?>

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<h1 class="text-3xl font-bold mb-6">Leave Details</h1>

<div class="bg-white p-6 rounded shadow-md">
    <h2 class="text-2xl font-bold mb-4">Leave for <?php echo e($leave->leave_type); ?></h2>
    <p><strong>Description:</strong> <?php echo e($leave -> start_date); ?> </p>
    <p><strong>Amount:</strong> <?php echo e($leave->end_date); ?></p>
    <p><strong>Status:</strong> <?php echo e($leave->reason); ?></p>
    <p><strong>Status:</strong> <?php echo e($leave->status); ?></p>
    <p><strong>Status:</strong> <?php echo e($leave->comments); ?></p>
    <button 
        onclick="window.history.back()" 
        class="bg-blue-500 text-white px-4 py-2 rounded mt-4 hover:bg-blue-600"
    >
        Back to leave List
    </button>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Thilina\Documents\Jaan\JaanHR\resources\views/management/leave/leave-details.blade.php ENDPATH**/ ?>