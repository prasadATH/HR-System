<h2 class="text-2xl font-bold mb-4">Leave Management</h2>
<table class="w-full border-collapse border border-gray-300">
    <thead>
        <tr class="bg-gray-200">
            <th class="border border-gray-300 px-4 py-2">ID</th>
            <th class="border border-gray-300 px-4 py-2">Employee</th>
            <th class="border border-gray-300 px-4 py-2">Leave Type</th>
            <th class="border border-gray-300 px-4 py-2">Start Date</th>
            <th class="border border-gray-300 px-4 py-2">End Date</th>
            <th class="border border-gray-300 px-4 py-2">Reason</th>
            <th class="border border-gray-300 px-4 py-2">Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="border border-gray-300 px-4 py-2"><?php echo e($leave->id); ?></td>
                <td class="border border-gray-300 px-4 py-2"><?php echo e($leave->employee->first_name); ?> <?php echo e($leave->employee->last_name); ?></td>
                <td class="border border-gray-300 px-4 py-2"><?php echo e($leave->leave_type); ?></td>
                <td class="border border-gray-300 px-4 py-2"><?php echo e($leave->start_date); ?></td>
                <td class="border border-gray-300 px-4 py-2"><?php echo e($leave->end_date); ?></td>
                <td class="border border-gray-300 px-4 py-2"><?php echo e($leave->reason ?? 'N/A'); ?></td>
                <td class="border border-gray-300 px-4 py-2"><?php echo e($leave->status); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="7" class="border border-gray-300 px-4 py-2 text-center">No leave records found.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php /**PATH C:\Users\Thilina\Documents\Jaan\JaanHR\resources\views/management/leave-management.blade.php ENDPATH**/ ?>