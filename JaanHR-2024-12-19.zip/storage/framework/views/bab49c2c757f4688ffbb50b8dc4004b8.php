

<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
<body class="bg-gray-100">
    <div class="container mx-auto mt-10">
        <h1 class="text-3xl font-bold mb-6">Dashboard</h1>

        <?php if(session('success')): ?>
            <div class="bg-green-100 text-green-800 p-3 rounded mb-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="bg-white p-6 rounded shadow-md mb-6">
            <p class="text-gray-700 text-lg">Welcome, <strong><?php echo e(auth()->user()->name); ?></strong>!</p>
            <p class="text-gray-600 mt-2">Your email: <?php echo e(auth()->user()->email); ?></p>
        </div>

        <h2 class="text-2xl font-bold mb-4">Employee List</h2>
        <div class="bg-white p-6 rounded shadow-md">
            <table class="w-full border-collapse border border-gray-300">
                <thead>
                    <tr class="bg-gray-200">
                        <th class="border border-gray-300 px-4 py-2">ID</th>
                        <th class="border border-gray-300 px-4 py-2">First Name</th>
                        <th class="border border-gray-300 px-4 py-2">Last Name</th>
                        <th class="border border-gray-300 px-4 py-2">Email</th>
                        <th class="border border-gray-300 px-4 py-2">Phone</th>
                        <th class="border border-gray-300 px-4 py-2">Position</th>
                        <th class="border border-gray-300 px-4 py-2">Department</th>
                        <th class="border border-gray-300 px-4 py-2">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="border border-gray-300 px-4 py-2"><?php echo e($employee->id); ?></td>
                            <td class="border border-gray-300 px-4 py-2"><?php echo e($employee->first_name); ?></td>
                            <td class="border border-gray-300 px-4 py-2"><?php echo e($employee->last_name); ?></td>
                            <td class="border border-gray-300 px-4 py-2"><?php echo e($employee->email); ?></td>
                            <td class="border border-gray-300 px-4 py-2"><?php echo e($employee->phone); ?></td>
                            <td class="border border-gray-300 px-4 py-2"><?php echo e($employee->position->title ?? 'N/A'); ?></td>
                            <td class="border border-gray-300 px-4 py-2"><?php echo e($employee->department->name ?? 'N/A'); ?></td>
                            <td class="border border-gray-300 px-4 py-2">
                                <a href="#" class="text-blue-500 hover:underline">Edit</a> |
                                <a href="#" class="text-red-500 hover:underline">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="border border-gray-300 px-4 py-2 text-center">No employees found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

                <!-- Button to Employee Dashboard -->
                <div class="mb-6">
            <a href="<?php echo e(route('dashboard.section', 'employee')); ?>" class="bg-blue-500 text-white px-6 py-2 rounded shadow hover:bg-blue-600">
                Go to Employee Dashboard
            </a>
        </div>

        <form method="POST" action="<?php echo e(route('logout')); ?>" class="mt-6">
            <?php echo csrf_field(); ?>
            <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded">Logout</button>
        </form>
    </div>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Thilina\Documents\Jaan\JaanHR\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>