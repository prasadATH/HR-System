<form action="<?php echo e(route('expenses.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <div class="mb-4">
        <label class="block text-gray-700 font-bold mb-2">Description</label>
        <input type="text" name="description" class="w-full p-2 border rounded" required>
    </div>

    <div class="mb-4">
        <label class="block text-gray-700 font-bold mb-2">Amount</label>
        <input type="number" step="0.01" name="amount" class="w-full p-2 border rounded" required>
    </div>

    <div class="mb-4">
        <label class="block text-gray-700 font-bold mb-2">Status</label>
        <select name="status" class="w-full p-2 border rounded" required>
            <option value="Pending">Pending</option>
            <option value="Approved">Approved</option>
            <option value="Rejected">Rejected</option>
        </select>
    </div>

    <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Add Expense</button>
    
<?php /**PATH C:\Users\Thilina\Documents\Jaan\JaanHR\resources\views/management/expenses/expenses-add.blade.php ENDPATH**/ ?>