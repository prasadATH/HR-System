

<?php $__env->startSection('title', 'Payroll Management'); ?>

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<h1 class="text-3xl font-bold mb-6">Payroll Management</h1>

<div class="bg-white p-6 rounded shadow-md">
    <h2 class="text-2xl font-bold mb-4">Payroll Records</h2>

    <table class="w-full border-collapse border border-gray-300">
        <thead>
            <tr class="bg-gray-200">
                <th class="border border-gray-300 px-4 py-2">ID</th>
                <th class="border border-gray-300 px-4 py-2">Payroll Month</th>
                <th class="border border-gray-300 px-4 py-2">Employee</th>
                <th class="border border-gray-300 px-4 py-2">Net Salary</th>
                <th class="border border-gray-300 px-4 py-2">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $payrolls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payroll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-100 cursor-pointer" onclick="window.location.href='<?php echo e(route('payroll.details', $payroll->id)); ?>'">
                    <td class="border border-gray-300 px-4 py-2"><?php echo e($payroll->id); ?></td>
                    <td class="border border-gray-300 px-4 py-2"><?php echo e($payroll->payroll_month); ?></td>
                    <td class="border border-gray-300 px-4 py-2"><?php echo e($payroll->employee->first_name); ?> <?php echo e($payroll->employee->last_name); ?></td>
                    <td class="border border-gray-300 px-4 py-2"><?php echo e(number_format($payroll->net_salary, 2)); ?></td>
                    <td class="border border-gray-300 px-4 py-2">
                        <a href="<?php echo e(route('payroll.details', $payroll->id)); ?>" class="text-blue-500 hover:underline">View Details</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="border border-gray-300 px-4 py-2 text-center">No payroll records found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Thilina\Documents\Jaan\JaanHR\resources\views/management/payroll-management.blade.php ENDPATH**/ ?>