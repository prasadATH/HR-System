<!-- Partial View: Subordinates -->
<div class="employees-row flex justify-center w-full relative" style="min-width: max-content;">
    <?php if($employees->count() > 1): ?>
        <!-- Horizontal Line Connecting Dots -->
        <div class="absolute top-0 left-0 w-full h-0.5 bg-gray-300 z-0"></div>
    <?php endif; ?>

    <div class="flex items-center">
        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex flex-col items-center mx-8 relative" style="min-width: 150px;">
                <!-- Circular Dot -->
                <div class="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-4 h-4 bg-blue-500 rounded-full border-2 border-white z-10"></div>

                <!-- Subordinate Card -->
                <div class="flex flex-col items-center mt-2">
                    <img src="<?php echo e(asset('/employee.png')); ?>" class="w-20 h-20 rounded-full border-2 border-green-500">
                    <p class="text-sm font-bold mt-2"><?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?></p>
                    <p class="text-xs text-gray-600">Employee ID: <?php echo e($employee->id); ?></p>
                    <p class="text-xs text-gray-600"><?php echo e($employee->title ?? 'No Title'); ?></p>
                </div>

                <!-- Recursive Subordinates -->
                <?php if($employee->subordinates->isNotEmpty()): ?>
                    <div class="flex justify-center mt-4 w-full">
                        <?php echo $__env->make('management.employee.partials.subordinates', ['employees' => $employee->subordinates], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH C:\Users\Thilina\Documents\Jaan\JaanHR\resources\views/management/employee/partials/subordinates.blade.php ENDPATH**/ ?>