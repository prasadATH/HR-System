

<?php $__env->startSection('title', 'Payroll Details'); ?>

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<h1 class="text-3xl font-bold mb-6">Payroll Details</h1>

<div class="bg-white p-6 rounded shadow-md">
    <h2 class="text-2xl font-bold mb-4">Payroll for <?php echo e($payroll->payroll_month); ?></h2>
    <p><strong>Employee Name:</strong> <?php echo e($payroll->employee->first_name); ?> <?php echo e($payroll->employee->last_name); ?></p>
    <p><strong>Basic Salary:</strong> <?php echo e(number_format($payroll->basic_salary, 2)); ?></p>
    <p><strong>Allowances:</strong> <?php echo e(number_format($payroll->allowances, 2) ?? 'N/A'); ?></p>
    <p><strong>Deductions:</strong> <?php echo e(number_format($payroll->deductions, 2) ?? 'N/A'); ?></p>
    <p><strong>Net Salary:</strong> <?php echo e(number_format($payroll->net_salary, 2)); ?></p>
    <p><strong>Generated At:</strong> <?php echo e($payroll->created_at->format('d M Y, H:i:s')); ?></p>
    <p><strong>Last Updated:</strong> <?php echo e($payroll->updated_at->format('d M Y, H:i:s')); ?></p>

    <button 
        onclick="window.history.back()" 
        class="bg-blue-500 text-white px-4 py-2 rounded mt-4 hover:bg-blue-600"
    >
        Back to Payroll List
    </button>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Thilina\Documents\Jaan\JaanHR\resources\views/management/payroll-details.blade.php ENDPATH**/ ?>