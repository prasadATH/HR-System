<nav class="bg-blue-500 text-white p-4">
    <a href="<?php echo e(route('home')); ?>" class="px-4">Home</a>
    <?php if(auth()->guard()->check()): ?>
        <a href="<?php echo e(route('dashboard')); ?>" class="px-4">Dashboard</a>
        <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline">
            <?php echo csrf_field(); ?>
            <button type="submit" class="px-4">Logout</button>
        </form>
    <?php else: ?>
        <a href="<?php echo e(route('login')); ?>" class="px-4">Login</a>
        <a href="<?php echo e(route('register')); ?>" class="px-4">Register</a>
    <?php endif; ?>
</nav>
<?php /**PATH C:\Users\Thilina\Documents\Jaan\JaanHR\resources\views/components/navbar.blade.php ENDPATH**/ ?>