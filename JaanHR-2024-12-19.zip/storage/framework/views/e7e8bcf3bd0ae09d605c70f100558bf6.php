

<?php $__env->startSection('title', 'Employee Details'); ?>

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<h1 class="text-3xl font-bold mb-6">Employee Details</h1>

<div class="bg-white p-6 rounded shadow-md">
    <h2 class="text-2xl font-bold mb-4"><?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?></h2>
    <p><strong>Email:</strong> <?php echo e($employee->email); ?></p>
    <p><strong>Phone:</strong> <?php echo e($employee->phone); ?></p>
    <p><strong>Position:</strong> <?php echo e($employee->position->title ?? 'N/A'); ?></p>
    <p><strong>Department:</strong> <?php echo e($employee->department->name ?? 'N/A'); ?></p>
    <p><strong>Address:</strong> <?php echo e($employee->address); ?></p>
    <p><strong>Date of Birth:</strong> <?php echo e($employee->date_of_birth); ?></p>
    <p><strong>Hire Date:</strong> <?php echo e($employee->hire_date); ?></p>
    <p><strong>Salary:</strong> <?php echo e($employee->salary); ?></p>
    <p><strong>Additional Notes:</strong> <?php echo e($employee->notes); ?></p>

    <button 
        onclick="window.history.back()" 
        class="bg-blue-500 text-white px-4 py-2 rounded mt-4 hover:bg-blue-600"
    >
        Back to Employee List
    </button>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Thilina\Documents\Jaan\JaanHR\resources\views/management/employee-details.blade.php ENDPATH**/ ?>