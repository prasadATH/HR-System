

<?php $__env->startSection('title', 'Employee Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full flex h-auto bg-[#FFFFFF]">
    <div class="flex flex-col items-start justify-start w-full px-16">
        <div class="w-full flex space-y-2 space-x-8 border-b-2 border-[#00000080] pb-8 pl-8 pt-8">
            <div class="flex w-5/6">
            <form method="GET" action="<?php echo e(route('employees.search')); ?>" class="w-full">
                <input name="search" id="input-field" type="text" placeholder="Search employee here" 
                    class="w-full px-4 py-2 border-2 border-[#00000080] text-2xl text-[#00000080] rounded-xl"
                    value="<?php echo e(request('search')); ?>" />
                    <button type="submit"> search</button>
            </div>
 
            </form>
            <div class="flex items-center justify-center w-20 p-4 border-2 border-black rounded-full">
                <p class="text-3xl"><i class="ri-notification-4-line"></i></p>
            </div>
            <div class="flex items-center justify-center w-20 border-2 border-black rounded-full">
                <img src="<?php echo e(asset('build/assets/bg1.png')); ?>" class="object-cover w-8 h-12">
            </div>
            <div class="flex items-center justify-center w-20">
                <p class="text-3xl"><i class="ri-arrow-down-s-fill"></i></p>
            </div>
        </div>
        <div class="w-full pt-8">
            <div class="flex items-center justify-between w-full">
                <div class="flex">
                    <p class="text-6xl font-bold text-black nunito-">EMPLOYEE</p>
                </div>
                <div class="flex items-center space-x-4">
                    <!-- Filter Button -->
                    <button class="flex items-center justify-between w-1/3 px-4 py-2 text-[#00000066] text-2xl bg-[#D9D9D980] border-2 border-[#D9D9D980] rounded-md hover:bg-gray-200">
                        <p class="text-3xl"><i class="ri-filter-2-line"></i></p>
                        <span>Filter</span>
                        <p class="text-3xl text-[#00000066]"><i class="ri-arrow-down-s-line"></i></p>
                    </button>
                    <!-- Add Employee Button -->
                    <a href="<?php echo e(route('employees.create')); ?>" 
   class="flex items-center justify-center space-x-2 px-8 py-2 text-white text-2xl bg-gradient-to-r from-[#184E77] to-[#52B69A] rounded-xl shadow-sm hover:from-[#1B5A8A] hover:to-[#60C3A8]">
    <p class="text-3xl"><i class="ri-add-fill"></i></p>
    <span>Add Employee</span>
</a>
                </div>
            </div>
        </div>
        <nav class="flex px-5 py-3" aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-3">
                <li class="inline-flex items-center">
                    <a href="#" class="inline-flex items-center text-3xl font-medium text-[#00000080] hover:text-blue-600">
                        Employee
                    </a>
                </li>
                <li>
                    <div class="flex items-center">
                        <p class="text-[#00000080] text-3xl"><i class="ri-arrow-right-wide-line"></i></p>
                        <a href="#" class="ml-1 font-medium text-[#00000080] text-3xl hover:text-blue-600">Employee Management</a>
                    </div>
                </li>
            </ol>
        </nav>
        <div class="flex">
 
        <?php if(request('search')): ?>
            <span class="text-xl text-[#00000080]">- Results for "<?php echo e(request('search')); ?>"</span>
        <?php endif; ?>
 
</div>
        <!-- Dynamic Employee Cards -->
        <div class="w-full grid grid-cols-1 md:grid-cols-4 gap-8 items-center pt-8 pb-8">

<?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="<?php echo e(route('employee.show', $employee->id)); ?>" class="block">
<div class="border-2 border-[#00000066] p-8 space-y-4 rounded-3xl">
<div class="w-full flex justify-center items-center">
<div class="w-1/2 flex justify-start items-center">
<img src="<?php echo e($employee->image ? asset('storage/' . $employee->image) : asset('build/assets/bg1.png')); ?>" class="w-32 h-32 rounded-full">
</div>
<div class="w-1/2 flex flex-col justify-center items-center space-y-8 pt-4">
<div class="w-full h-1/2 flex justify-center items-center">
<span class="px-6 py-1 text-sm font-medium rounded-xl
           <?php echo e($employee->current === 'Active' ? 'text-[#008526] bg-[#9ce99280] border border-[#47B439] rounded-xl' : 'text-[#ad0000] bg-[#ffb5b5] border-[#FF0000]'); ?>">
    <?php echo e($employee->current); ?>

</span>

</div>
<div class="w-full h-1/2 flex flex-col justify-start items-center">
<p class=" text-[#00000080] nunito-">Employee ID</p>
<p class="text-black nunito-" style="font-weight: 700;"><?php echo e($employee->id); ?></p>
</div>
</div>
</div>
<div class="w-full flex flex-col space-y-2 pt-4">
<p class="text-4xl text-black nunito- font-bold" style="font-weight: 700;"><?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?></p>
<p class="text-2xl nunito- text-[#00000080] font-bold" style="font-weight: 700;"><?php echo e($employee->title); ?></p>
</div>
<div class="w-full flex justify-between items-center">
<div class="w-full flex flex-col">
<p class="text-xl nunito- text-[#00000080] font-bold">Department</p>
<p class="text-l nunito- text-black font-bold" style="font-weight: 700;"><?php echo e($employee->department->name ?? 'No Department'); ?></p>
</div>
<div class="w-full flex flex-col">
<p class="text-xl nunito- text-[#00000080] font-bold">Hired Date </p>
<p class="text-l nunito- text-black font-bold" style="font-weight: 700;"><?php echo e($employee->probation_start_date); ?></p>
</div>

</div>
<div class="w-full flex flex-col justify-start items-start space-y-4">
<div class="w-full flex justify-start items-center space-x-2">
<div class="w-8 h-8 flex justify-center items-center border border-black rounded-full p-1">
<p class="text-xl"><i class="ri-mail-line"></i></p>
</div>
<p class="text-black font-bold nunito-" style="font-weight: 600;"><?php echo e($employee->email); ?></p>
</div>
<div class="w-full flex justify-start items-center space-x-2">
<div class="w-8 h-8 flex justify-center items-center border border-black rounded-full p-1">
<p class="text-xl"><i class="ri-phone-line"></i></p>
</div>
<p class="text-black font-bold nunito-" style="font-weight: 600;"><?php echo e($employee->phone); ?></p>
</div>
</div>
</div>
</a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>



        

<!-- Pagination -->
<div class="w-full flex justify-center items-center pt-4">
    <?php echo e($employees->appends(['search' => request('search')])->links('vendor.pagination.tailwind')); ?>

</div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Thilina\Documents\Jaan\JaanHR\resources\views/management/employee/employee-management.blade.php ENDPATH**/ ?>