<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Employee;
use App\Models\Payroll;
use App\Models\Leave;
use App\Models\Loan;
use App\Models\ExpenseClaim;
use App\Models\Attendance;
use App\Models\Incident;

class ManagementController extends Controller
{

    public function employeeManagement()
    {
        $employees = Employee::with(['department'])->paginate(8);
        $section = "employee";
    
        return view('management.employee.employee-management', compact('section', 'employees'));

    }
    public function payrollManagement()
    {
        $payrolls = Payroll::all();
        return view('management.payroll.payroll-management', compact('payrolls'));
    }

    public function leaveManagement()
    {
        $leaves = Leave::all();
        return view('management.leave.leave-management', compact('leaves'));
    }



    public function expenseManagement()
    {
        $expenses = ExpenseClaim::paginate(15); // Fetch paginated data
     //   dd($expenses);
        return view('management.expenses.expenses-management', compact('expenses'));
    }

    
    public function incidentManagement()
    {
        $incidents = Incident::paginate(10); // Fetch paginated data
     //   dd($expenses);
        return view('management.incident.incident-management', compact('incidents'));
    }



    public function attendanceManagement()
    {
        $attendance = Attendance::with(['employee'])->paginate(10); // Fetch paginated data
     //   dd($expenses);
     $attendance->getCollection()->transform(function ($record) {
        $record->total_work_hours = $this->formatDuration($record->total_work_hours);
        $record->overtime_hours = $this->formatDuration($record->overtime_seconds);
        $record->late_by = $this->formatDuration($record->late_by_seconds);

        return $record;
    });

    return view('management.attendance.attendance-management', compact('attendance'));
}

public function advanceManagement()
{
    $advances = Loan::all();
    return view('management.advance.advance-management', compact('advances'));
}
    



/**
 * Helper function to convert seconds to HH:MM:SS format.
 *
 * @param int|null $seconds
 * @return string|null
 */
private function formatDuration($seconds)
{
    if ($seconds === null) {
        return null;
    }

    $hours = floor($seconds / 3600);
    $minutes = floor(($seconds % 3600) / 60);
    $remainingSeconds = $seconds % 60;

    return sprintf('%02d:%02d:%02d', $hours, $minutes, $remainingSeconds);
}

}
