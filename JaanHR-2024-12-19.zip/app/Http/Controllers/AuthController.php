<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Illuminate\Support\Facades\Password;
use Illuminate\Http\RedirectResponse;

class AuthController extends Controller
{
    /**
     * Show the login page (GET method).
     */
    public function showLogin()
    {
        if (Auth::check()) {
            return redirect('/management/employee-management'); 
        }
        
        return view('authentification.login');
    }

    /**
     * Show the registration page (GET method).
     */
    public function showRegister()
    {
        if (Auth::check()) {
            return redirect('/management/employee-management'); 
        }
        return view('authentification.register');
    }

    /**
     * Handle user registration (POST method).
     */
    /**
 * Handle user registration (POST method).
 */
public function register(Request $request)
{
    $request->validate([
        'name' => 'required|string|max:255',
        'email' => 'required|email|unique:users',
        'password' => 'required|min:8|confirmed',
    ]);

    // Create the user
    $user = User::create([
        'name' => $request->name,
        'email' => $request->email,
        'password' => Hash::make($request->password),
    ]);

    // Log the user in and store session data
    return redirect('/login'); 
    session(['user_id' => $user->id, 'user_name' => $user->name, 'user_email' => $user->email]);

    return redirect('/dashboard')->with('success', 'Registration successful! You are now logged in.');
}

    /**
     * Handle user login (POST method).
     */
    /**
 * Handle user login (POST method).
 */
public function login(Request $request)
{
    $request->validate([
        'email' => 'required|email',
        'password' => 'required',
    ]);

    if (!Auth::attempt($request->only('email', 'password'))) {
        return back()->withErrors(['email' => 'Invalid credentials.']);
    }

    $request->session()->regenerate();

    return redirect()->intended('/management/employee-management'); // Redirect to intended page or default
}
    
    /**
     * Handle user logout (POST method).
     */
    /**
 * Handle user logout (POST method).
 */
public function logout(Request $request)
{
    Auth::logout();

    $request->session()->invalidate();
    $request->session()->regenerateToken();

    return redirect('/login');
}



    public function showForgotPassword()
    {
        return view('authentification.forgotpassword');
    }
    
    public function handleForgotPassword(Request $request)
    {
        // Validate the email
        $request->validate(['email' => 'required|email|exists:users,email']);
        
        // Attempt to send the password reset link
        $status = Password::sendResetLink(
            $request->only('email')
        );
        
        // Check the status and respond accordingly
        if ($status === Password::RESET_LINK_SENT) {
            // Render the password link confirmation view
            return view('authentification.passwordlinkconfirmation', [
                'email' => $request->email, // Pass the email to the view
            ]);
        }
        
        // If there was an issue, return an error
        return redirect()->back()->withErrors(['email' => __($status)]);
    }
    
    
    public function showResetLinkConfirmation($email)
{
    return view('authentification.passwordlinkconfirmation', ['email' => $email]);
}
    public function showResetForm($token)
{
    return view('authentification.passwordreset', ['token' => $token]);
}

public function updateNewPassword(Request $request)
{
    $request->validate([
        'email' => 'required|email|exists:users,email',
        'password' => [
            'required',
            'min:8',
            'confirmed',
            'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/', // At least one uppercase, one lowercase, and one number
        ],
    ]);

    $user = User::where('email', $request->email)->first();

    if ($user) {
        try {
            $user->forceFill([
                'password' => Hash::make($request->password),
            ])->save();

            return view('authentification.passwordresetsuccess')->with('status', __('Your password has been reset successfully.'));
        } catch (\Exception $e) {
            return back()->withErrors(['email' => __('An error occurred while updating the password. Please try again.')]);
        }
    }

    return back()->withErrors(['email' => __('User not found. Please check the email address.')]);
}




public function showResetSuccess()
{
    return view('authentification.passwordlinkconfirmation');
}

}
